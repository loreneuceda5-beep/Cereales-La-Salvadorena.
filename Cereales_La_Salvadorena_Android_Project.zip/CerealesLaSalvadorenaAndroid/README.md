# Cereales La Salvadoreña — Android
Proyecto Android que empaqueta la aplicación local existente en un WebView. Datos guardados localmente, sin nube.

## Obtener el APK
Sube estos archivos a un repositorio GitHub; después abre Actions y ejecuta “Build Android APK”. Descarga el artefacto `Cereales-La-Salvadorena-APK`; dentro estará `app-debug.apk` para instalarlo en Android.

La aplicación incluye catálogo, inventario, movimientos, ventas, historial y comprobante PDF de 80 mm. El comprobante es interno, no una factura tributaria autorizada. El APK generado es debug, para instalación directa, no para Play Store.
